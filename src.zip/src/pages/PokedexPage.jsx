import React, { useEffect, useState } from "react";
// Importando o componente de navbar
import NavBar from "../components/NavBar";
// importando o card do pokemon
import PokemonCard from "../components/PokemonCard/index";
import '../css/Home.css'
// importando o axios
import axios from 'axios';
// Importando estilos do mui material
import { Box, Grid } from "@mui/material";
import { Container } from "@mui/system";
import { Skeletons } from "../components/Skeletons";

// Componente que retorna a página cheia de Pokémons
export const PokedexPage = () => {
    
    const [pokemons, setPokemons] = useState([]);
    // Imprime no console os 50 Pokemons da API quando o componente getPokemons é criado e atualiza
    useEffect(() => {
        getPokemons(), [];
    });
    const getPokemons = () => {
        // Criando endpoints para imagens e mais dados dos Pokemons
        var endpoints = []
            for( var i = 1; i<50; i++){
                endpoints.push(`https://pokeapi.co/api/v2/pokemon/${i}/`);
            }
        // Realizando uma requisição para cada endpoint de pokemon
         axios.all(endpoints.map((endpoint) => axios.get(endpoint))).then((res) => setPokemons(res));
    };

    // Criando uma função que filtra os Pokemons
    // Ela verifica se o nome pesquisado corresponde 
    // a um Pokémon existente e armazena em outro array
    const pokemonFilter = (name) => {
        var filteredPokemons = [];
        if (name === ""){
            getPokemons(); 
        }
        for (var i in pokemons){
            if(pokemons[i].data.name.includes(name)){
                filteredPokemons.push(pokemons[i]); // adiciona um novo item ao array se o nome do pokemon for igual ao pesquisado
            }
        }
        setPokemons(filteredPokemons);
    };
   
    return(
        <>
            <div className="home-fundo">
                <NavBar pokemonFilter={pokemonFilter}/>
                <Container maxWidth={false}>
                    <Grid container spacing={3}>
                        {/* Exibindo o skeleton para caso algo na página não carregue */}
                        {pokemons.length === 0 ? (
                        <Skeletons />
                        ) : (
                            /* Cada pokemons.map retorna um card de pokemon na tela (nesse caso 50 Pokemons da API)*/
                            pokemons.map((pokemon, key) => (
                            <Grid item xs={12} sm={6} md={4} lg={2} key={key}>
                                <Box onClick={() => pokemonPickHandler(pokemon.data)}>
                                    {/* Criando uma props para passar o nome do Pokemon, sua imagem e seu tipo*/}
                                    <PokemonCard name={pokemon.data.name} image={pokemon.data.sprites.front_default} types={pokemon.data.types} />
                                </Box>
                            </Grid>
                        ))
                    )}
                    </Grid>
                </Container>       
            </div>
        </>
    );
};