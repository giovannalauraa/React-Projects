import './Content.css'
import { Routes, Route } from 'react-router-dom'

import Pokedex from '../../views/pages/Pokedex'
import Jogo from '../JogoMario/Jogo'
import NotFound from '../../pages/NotFound'

// Rotas configuradas para o menu 
const Content = props => (
    <>
        <aside className="Content">
            <Routes>
                <Route path="/pokedex" element={<Pokedex />} />
                <Route path="/jogo" element={<Jogo />} />
                <Route path="/" element={<Pokedex />} />
                <Route path="*" element={<NotFound />} /> 
            </Routes>
        </aside>
    </>
)

export default Content