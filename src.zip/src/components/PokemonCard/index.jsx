import * as React from 'react';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import { CardActionArea } from '@mui/material';

// Componente que retorna um card de Pokemon 
export default function PokemonCard({ name, image, types}) { // Passando por uma props o nome e imagem do Pokemon vindo da API
  
  // Criando uma função para retornar os tipos do Pokémon se ele tiver mais de um
  const typeHandler = () => {
    if(types[1]){
      return types[0].type.name + " | " + types[1].type.name;
    }
    return types[0].type.name;
  }

  return (
    <Card sx={{ maxWidth: 345, boxShadow: "5px 5px 10px rgba(0, 0, 0, 0.5)"}}>
    <CardActionArea>
        <CardMedia 
            component="img"
            height="200"
            image={image}
            title="Pokemon"
        />
        <CardContent>
        <Typography gutterBottom variant="h5" component="div">
         { name }
        </Typography>
        <Typography gutterBottom variant="capiton" component="div">
         {/* Chamando a função que mostra o tipo do Pokémon */}
         { typeHandler() }
        </Typography>
    </CardContent>
    </CardActionArea>
    </Card>
  );
}
