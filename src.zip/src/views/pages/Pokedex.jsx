import { PokedexPage } from "../../pages/PokedexPage"

// Componente que retorna a página de pokémon para a rota configurada
const PokedexC = props => (
    <>
        <div className="PokedexC">
            <PokedexPage />
        </div>
    </>
)

export default PokedexC
