// Componente que retorna uma página de NotFound 
const NotFound = props => (
    <>
        <div className="NotFound">
            <h1>Componente NotFound</h1>
            <p>Página não encontrada!!!</p>
        </div>
    </>
)

export default NotFound